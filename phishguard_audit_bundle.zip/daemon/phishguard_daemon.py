import subprocess
import sys
import time
import os

BACKEND_DIR = r"E:\phish-guard-ai\backend"
PYTHON_EXE = r"E:\phish-guard-ai\venv\Scripts\python.exe"

def run_daemon():
    while True:
        try:
            # تشغيل سيرفر FastAPI في الخلفية كعملية صامتة
            cmd = [PYTHON_EXE, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8000", "--app-dir", BACKEND_DIR]
            process = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            process.wait()
        except Exception as e:
            time.sleep(5)

if __name__ == "__main__":
    run_daemon()