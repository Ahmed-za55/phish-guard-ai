(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_next_dist_compiled_14ibvna._.js","static/chunks/node_modules_next_dist_shared_lib_1vsvqbg._.js","static/chunks/node_modules_next_dist_client_16lnmlo._.js","static/chunks/node_modules_next_dist_1atto1n._.js","static/chunks/[next]_entry_page-loader_ts_1aoli7m._.js","static/chunks/node_modules_react-dom_0kla17-._.js","static/chunks/node_modules_10e2-xo._.js","static/chunks/[root-of-the-server]__02sxxph._.js"],
    source: "entry"
});
